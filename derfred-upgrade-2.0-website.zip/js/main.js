
document.addEventListener("DOMContentLoaded", function() {
  var toggles = document.querySelectorAll(".nav-toggle");
  toggles.forEach(function(btn) {
    btn.addEventListener("click", function() {
      var shell = btn.closest(".nav-shell");
      if (shell) {
        shell.classList.toggle("nav-open");
      }
    });
  });
});
